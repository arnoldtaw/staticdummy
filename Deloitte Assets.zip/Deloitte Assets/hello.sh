#!/bin/bash

echo "hello"
say "hello" 

exit 0